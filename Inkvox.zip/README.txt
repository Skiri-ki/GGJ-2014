Just run the app and then stroll around :).

Every time you start the game, you get a world completely anew.

Std builds are for normal use
OR builds are to be used with Oculus Rift